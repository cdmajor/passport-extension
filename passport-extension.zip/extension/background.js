// Passport — background service worker
// Handles proxy switching, translation, and subscription verification.

const API_BASE = "https://git-hub-publisher.replit.app/api";
const ACTIVATE_PATH = "/passport-activate";

// ─── State ────────────────────────────────────────────────────────────────────

let activeCountry = null;
let subscriptionActive = false;

// Restore persisted state on startup
chrome.storage.local.get(["activeCountry", "membershipId"], async (result) => {
  if (result.membershipId) {
    subscriptionActive = await verifyMembership(result.membershipId);
  }
  if (result.activeCountry && subscriptionActive) {
    activeCountry = result.activeCountry;
    applyProxy(activeCountry.code);
  }
});

// ─── Auto-capture membership after checkout ───────────────────────────────────

chrome.webNavigation.onCompleted.addListener(
  async (details) => {
    try {
      const url = new URL(details.url);
      const membershipId = url.searchParams.get("membership_id");
      if (!membershipId) return;

      const active = await verifyMembership(membershipId);
      if (active) {
        await chrome.storage.local.set({ membershipId });
        subscriptionActive = true;
        // Close the activation tab
        chrome.tabs.remove(details.tabId);
        // Notify popups
        chrome.runtime.sendMessage({ type: "SUBSCRIPTION_ACTIVATED" }).catch(() => {});
      }
    } catch {
      // ignore
    }
  },
  { url: [{ hostEquals: "git-hub-publisher.replit.app", pathPrefix: ACTIVATE_PATH }] }
);

// ─── Message Handling ─────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  switch (message.type) {
    case "GET_STATUS":
      sendResponse({ activeCountry, subscriptionActive });
      return false;

    case "CHECK_SUBSCRIPTION":
      chrome.storage.local.get(["membershipId"], async ({ membershipId }) => {
        if (!membershipId) {
          sendResponse({ active: false });
          return;
        }
        const active = await verifyMembership(membershipId);
        subscriptionActive = active;
        sendResponse({ active });
      });
      return true;

    case "START_CHECKOUT":
      startCheckout()
        .then((url) => sendResponse({ ok: true, url }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;

    case "SET_COUNTRY":
      if (!subscriptionActive) {
        sendResponse({ ok: false, error: "subscription_required" });
        return false;
      }
      setCountry(message.country)
        .then(() => sendResponse({ ok: true }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;

    case "CLEAR_COUNTRY":
      clearProxy()
        .then(() => sendResponse({ ok: true }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;

    case "TRANSLATE_BATCH":
      translateBatch(message.texts, message.targetLanguage)
        .then((translations) => sendResponse({ ok: true, translations }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;

    case "DETECT_LANGUAGE":
      detectLanguage(message.sample)
        .then((language) => sendResponse({ ok: true, language }))
        .catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;
  }
});

// ─── Subscription ─────────────────────────────────────────────────────────────

async function verifyMembership(membershipId) {
  try {
    const res = await fetch(`${API_BASE}/whop/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ membership_id: membershipId }),
    });
    if (!res.ok) return false;
    const data = await res.json();
    return !!data.active;
  } catch {
    return false;
  }
}

async function startCheckout() {
  const res = await fetch(`${API_BASE}/whop/checkout`, { method: "POST" });
  if (!res.ok) throw new Error("Failed to create checkout session");
  const data = await res.json();
  chrome.tabs.create({ url: data.purchase_url });
  return data.purchase_url;
}

// ─── Proxy Management ─────────────────────────────────────────────────────────

async function setCountry(country) {
  const res = await fetch(`${API_BASE}/proxy/config/${country.code}`);
  if (!res.ok) throw new Error(`Could not load proxy config for ${country.code}`);
  const { host, port, protocol } = await res.json();

  await applyProxyConfig({ host, port, protocol });

  activeCountry = country;
  await chrome.storage.local.set({ activeCountry });

  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    chrome.tabs.sendMessage(tab.id, { type: "COUNTRY_CHANGED", country }).catch(() => {});
  }
}

function applyProxyConfig({ host, port, protocol }) {
  return new Promise((resolve, reject) => {
    const proxyType = protocol === "socks5" ? "SOCKS5" : "PROXY";
    const pac = `function FindProxyForURL(url, host) { return "${proxyType} ${host}:${port}"; }`;
    chrome.proxy.settings.set(
      { value: { mode: "pac_script", pacScript: { data: pac } }, scope: "regular" },
      () => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      }
    );
  });
}

async function applyProxy(countryCode) {
  try {
    const res = await fetch(`${API_BASE}/proxy/config/${countryCode}`);
    if (res.ok) {
      const config = await res.json();
      await applyProxyConfig(config);
    }
  } catch {
    await clearProxy();
  }
}

function clearProxy() {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else {
        activeCountry = null;
        chrome.storage.local.remove("activeCountry");
        resolve();
      }
    });
  });
}

// ─── Translation ──────────────────────────────────────────────────────────────

const BATCH_SIZE = 40;

async function translateBatch(texts, targetLanguage) {
  const results = [];
  for (let i = 0; i < texts.length; i += BATCH_SIZE) {
    const chunk = texts.slice(i, i + BATCH_SIZE);
    const translated = await callTranslateAPI(chunk, targetLanguage);
    results.push(...translated);
  }
  return results;
}

async function callTranslateAPI(texts, targetLanguage) {
  const res = await fetch(`${API_BASE}/translate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ texts, targetLanguage }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `Server error ${res.status}`);
  }
  const data = await res.json();
  if (!Array.isArray(data.translations)) throw new Error("Unexpected response format.");
  return data.translations;
}

async function detectLanguage(sample) {
  const res = await fetch(`${API_BASE}/detect`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sample }),
  });
  if (!res.ok) throw new Error(`Server error ${res.status}`);
  const data = await res.json();
  return data.language ?? "Unknown";
}
